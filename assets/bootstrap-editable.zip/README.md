bootstrap-editable
==================

In-place editing with Bootstrap Form and Popover